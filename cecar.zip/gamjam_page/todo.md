### template of game jam page
# todo
1. design it
2. make it responsive
3. make it dynamic!
yet all in **wip**