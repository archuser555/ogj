### design of the register page
# todo:
1. design it... **Kinda Done**
2. make it responsive **Done**
3. link it with the api via json an js **WIP**