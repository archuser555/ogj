<?php

/*cecar api*/
/* todo: getuserdatabyid feature, create an account, delete an account, getjamdatabyid, create jam, delete jam*/

?>