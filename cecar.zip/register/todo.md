### design of the register page
# todo:
1. design it...
2. make it responsive
3. link it with the api via json an js