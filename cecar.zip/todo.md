### It's Cecar!
**It's an open source platform where anyone can host his awesome game jams! without worry of any type of thos "Accept Terms To Continue"**

**We trying our best, a donation can help :D**
**XMR: 494h4XWowWtZcoPLU5FtbP22eTmWN8ir8UDvnpYPPmSo27x7z5ozKdpSzUsZrGwur9j4WGArQVjvo6FcWe6hFQAPLTdd2eE**


### Roadmap Of Work
# todos: 30 nov 2022
1. create simple navbar **DONE**
2. learn how to make hover buttons **DONE**
3. choose a nice color pallet **DONE**
# todos: 1 nov 2022
1. make a page template for game jam **DONE BUT NOT TOO GOOD**
2. make a game jam website generator in python or php **NOT DONE**
3. fetch game jam data from database **NOT DONE**
4. grid to fetch game jams and put them on first website **NOT DONE**
# todos: 2 dec 2022
1. Create an API to create & delete both users and jams **NOT DONE**
2. fetch data from database to website via json **NOT DONE**
